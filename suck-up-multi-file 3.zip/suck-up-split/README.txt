Suck Up! split project

Open index.html through a local web server or upload the whole folder to GitHub Pages.
Keep the folder structure intact:
- index.html: page structure and script loading
- css/style.css: all visual styling
- js/data.js: residents, disguises, dialogue data, constants
- js/game.js: game logic, settings, rendering and AI configuration
- js/world.js: 3D street exploration scene
- js/talk-scene.js: 3D doorstep conversation scene

Three.js and Google Fonts are loaded from their existing CDN URLs, so those features need an internet connection.
