"use strict";
const DAWN = 510;            // minutes after 9:00 PM until sunrise
const GOAL = 100;            // blood needed to call the night a success
const MAXHEAT = 3;
const START_MIN = 21 * 60;

const TAGS = { charm:"Charm", flatter:"Flatter", sob:"Sob story", offer:"Offer", bluff:"Bluff", menace:"Menace" };

const GUISES = [
  { id:"courier",   name:"Pizza courier",     blurb:"Hot box, wrong address, big smile." },
  { id:"lost",      name:"Lost traveler",     blurb:"Dead phone, kind face." },
  { id:"canvass",   name:"Charity canvasser", blurb:"Clipboard and a cause." },
  { id:"neighbor",  name:"New neighbor",      blurb:"Borrowing a cup of anything." },
  { id:"inspector", name:"Utility inspector", blurb:"Hi-vis vest, official voice." }
];

/* Outfits and props taken from residents you drink deep from */
const DROPS = {
  drop_marge:  { name:"Marge's cardigan", blurb:"Soft wool, reading glasses, a library card.", prop:"Library card", fits:["dex","rosa"],
                 aff:{marge:-2,dex:1,rosa:2,pruitt:0,imani:1,haskell:1} },
  drop_dex:    { name:"Dex's hoodie", blurb:"Faded hoodie, headphones, a dead phone.", prop:"Dead phone", fits:["marge","imani"],
                 aff:{marge:0,dex:-2,rosa:-1,pruitt:-1,imani:1,haskell:0} },
  drop_rosa:   { name:"Rosa's chef whites", blurb:"Stained apron and a tin of pastries.", prop:"Pastry tin", fits:["marge","dex","pruitt"],
                 aff:{marge:2,dex:2,rosa:-2,pruitt:1,imani:1,haskell:1} },
  drop_pruitt: { name:"Officer Pruitt's jacket", blurb:"Dark jacket, flashlight, a shiny badge.", prop:"Badge", fits:["marge","rosa","imani"],
                 aff:{marge:1,dex:-1,rosa:1,pruitt:-2,imani:2,haskell:1} },
  drop_imani:  { name:"Dr. Okafor's scrubs", blurb:"Hospital scrubs and a stethoscope.", prop:"Stethoscope", fits:["marge","pruitt","haskell"],
                 aff:{marge:2,dex:1,rosa:1,pruitt:1,imani:-2,haskell:1} },
  drop_haskell:{ name:"Haskell's waistcoat", blurb:"Brass buttons and a ticking pocket watch.", prop:"Pocket watch", fits:["marge","imani"],
                 aff:{marge:2,dex:0,rosa:1,pruitt:1,imani:1,haskell:-2} }
};
function guiseOf(id){ return DROPS[id] || GUISES.find(x => x.id === id) || { name:"stranger", blurb:"" }; }

const RES = [
  { id:"marge", name:"Marge Pellew", title:"Mrs. Pellew", role:"Retired librarian, 71", no:4,
    glimpse:"A kettle whistles somewhere inside. Lamplight falls on a tower of paperbacks.",
    opening:"The chain rattles. “Who is it at this hour? Yes?”",
    w:{charm:1,flatter:2,sob:2,offer:1,bluff:-1,menace:-3},
    aff:{courier:-1,lost:2,canvass:0,neighbor:2,inspector:-1},
    baseSusp:0, ward:0, slamHeat:1, drainHeat:1, value:20, vamp:false,
    likes:["book","read","tea","librar","garden","cat","novel","poem","story","cookie","shortbread"],
    dislikes:["loud","hurry","buy","sell","money","rude"],
    lines:{
      charm:"Such a lovely night for a visit, Mrs. Pellew. I saw your lamp on.",
      flatter:"I hope you don't mind me saying, yours is the prettiest garden on Larkspur Lane.",
      sob:"I'm so sorry to trouble you. I've been walking for hours and I'm terribly cold.",
      offer:"I brought a tin of shortbread. I thought someone might share a cup of tea.",
      bluff:"Records check for the library board. It will take two minutes.",
      menace:"Open the door, Marge. Don't make this unpleasant."},
    react:{
      great:"“Oh, you poor dear. Goodness, I haven't had a visitor in ages.”",
      good:"“Well. That's rather sweet of you to say.”",
      meh:"“Hm. I'm not sure what to make of that.”",
      bad:"“I don't care for your tone, young person.”",
      awful:"“I shall telephone someone if you carry on like that.”"},
    invite:"“Come in, come in, before the cold gets in. I'll put the kettle on.”",
    slam:"“Good night, dear. I'm sure I can't help you.” The bolt slides home." },

  { id:"dex", name:"Dex Moreno", title:"Dex", role:"College student, 20", no:7,
    glimpse:"Blue TV flicker and bass through the wall. Pizza boxes stacked in the window.",
    opening:"The door cracks open, headphones around his neck. “Yeah? You ordering something?”",
    w:{charm:1,flatter:0,sob:1,offer:2,bluff:-2,menace:-1},
    aff:{courier:2,lost:0,canvass:-1,neighbor:1,inspector:-2},
    baseSusp:0, ward:0, slamHeat:1, drainHeat:1, value:25, vamp:true,
    likes:["game","pizza","horror","movie","cosplay","halloween","stream","band","music","free","hungry","energy"],
    dislikes:["lecture","formal","rent","survey","official"],
    lines:{
      charm:"Hey man, whatever you're playing sounds intense. Mind if I say hi?",
      flatter:"That stream setup of yours is unreal. Did you build it yourself?",
      sob:"My ride bailed and I'm starving. Any chance you've got spare food?",
      offer:"I've got a free pizza nobody claimed. All yours, no strings.",
      bluff:"Property office. We need to check your smoke alarm tonight.",
      menace:"Open up. You really don't want me out here all night."},
    react:{
      great:"“Ha! Okay, you're actually cool. Hold on, let me pause my game.”",
      good:"“Huh. Okay, that's kind of funny.”",
      meh:"“Uh. Cool, I guess? It's one in the morning, man.”",
      bad:"“Dude, that's weirdly intense. Dial it back.”",
      awful:"“Okay, nope, I'm done. I'm holding my phone up at you.”"},
    invite:"“Alright, come in, there's room on the couch. Mind the pizza boxes.”",
    slam:"“Yeah, no. Go bother somebody else.” The door shuts." },

  { id:"rosa", name:"Rosa Delacroix", title:"Rosa", role:"Restaurant chef, 46", no:11,
    glimpse:"Steam fogs the glass. Braids of garlic hang across the kitchen window.",
    opening:"An apron, a wooden spoon, a garlic braid swinging behind her. “Yes? Make it quick.”",
    w:{charm:0,flatter:2,sob:1,offer:0,bluff:-1,menace:-2},
    aff:{courier:-2,lost:1,canvass:1,neighbor:2,inspector:-2},
    baseSusp:0, ward:4, slamHeat:1, drainHeat:1, value:20, vamp:false,
    likes:["food","cook","recipe","smell","soup","wine","kitchen","taste","delicious","flavor","bread","herb","sauce"],
    dislikes:["bland","boring","microwave","frozen","fast food","ketchup"],
    lines:{
      charm:"Something smells wonderful in there. Sorry, I couldn't walk past without saying so.",
      flatter:"Whatever you're cooking, it beats any restaurant I've been to.",
      sob:"I've had nothing but gas-station coffee all day. Could you spare a bite?",
      offer:"I picked up fresh bread from the corner. I'd trade it for a recipe.",
      bluff:"Quick health and safety check, ma'am. Five minutes.",
      menace:"Let me in. I can smell the dinner from here, and I'm not asking."},
    react:{
      great:"“Ah, a person with taste! Come, tell me what you smell.”",
      good:"“That's kind. Most people just ask when it's ready.”",
      meh:"“Mm. I'm busy. The sauce won't watch itself.”",
      bad:"“You're making me nervous, and I'm holding a knife.”",
      awful:"“That's enough. I'm shutting this door.”"},
    invite:"“Fine, fine, come in. Sit. You look hungry, and I hate that.”",
    slam:"“Not tonight. Ask someone else.” The door closes, and the garlic smell stays." },

  { id:"pruitt", name:"Officer Dale Pruitt", title:"Officer Pruitt", role:"Police officer, 38", no:15,
    glimpse:"A patrol car idles in the drive. A porch camera blinks red.",
    opening:"The porch light snaps on. “Evening. Pretty late. Can I help you?”",
    w:{charm:1,flatter:-1,sob:1,offer:-1,bluff:-2,menace:-3},
    aff:{courier:-1,lost:2,canvass:1,neighbor:1,inspector:-2},
    baseSusp:15, ward:2, slamHeat:2, drainHeat:1, value:30, vamp:false,
    likes:["officer","sir","thank","safe","community","service","coffee","help","lost","respect"],
    dislikes:["scam","trick","sell","lie","fang","cheap"],
    lines:{
      charm:"Good evening. I'm sorry for the hour. I'll be quick and polite about it.",
      flatter:"Fine house, Officer. You can tell someone here takes pride in the neighborhood.",
      sob:"My car died down the road and my phone's out. Could you point me to help?",
      offer:"Take a coffee, Officer. I've got a spare, on the house.",
      bluff:"County inspection. I'll need a look around inside.",
      menace:"You'll want to open this door right now. Trust me on that."},
    react:{
      great:"“Well. I appreciate the courtesy. Not many folks have it anymore.”",
      good:"“Hm. That's fair enough.”",
      meh:"“I'm listening. Don't take your time.”",
      bad:"“That doesn't sound right. Hands where I can see them.”",
      awful:"“Step back from the door. Now. I'm calling this in.”"},
    invite:"“All right. Come in, keep your hands visible, and I'll find a number for a tow.”",
    slam:"“Wait out there. I'm calling this in anyway.” The deadbolt thuds." },

  { id:"imani", name:"Dr. Imani Okafor", title:"Dr. Okafor", role:"ER doctor, 34", no:18,
    glimpse:"Scrubs on the line. One dim lamp, and a note on the door asking for a quiet knock.",
    opening:"Sleepy, hair half tied. “Hi? Are you hurt?”",
    w:{charm:1,flatter:0,sob:2,offer:2,bluff:-1,menace:-3},
    aff:{courier:1,lost:1,canvass:-1,neighbor:1,inspector:0},
    baseSusp:0, ward:0, slamHeat:1, drainHeat:1, value:25, vamp:false,
    likes:["tired","sleep","quiet","coffee","thank","nurse","doctor","patient","hospital","calm","tea"],
    dislikes:["loud","noisy","shout","sell","survey"],
    lines:{
      charm:"A quiet night. I won't take up more than a minute of yours.",
      flatter:"People in your line of work are rare. You must be wonderful at your job.",
      sob:"I'm feeling dizzy and cold. I think I need to sit down somewhere safe.",
      offer:"I have a hot coffee here I haven't touched. It's yours.",
      bluff:"I'm with the city. We're checking a possible gas leak on this street.",
      menace:"I'm coming in. You'd be wise to let me."},
    react:{
      great:"“Oh. Thank you. You have no idea what that means after tonight's shift.”",
      good:"“That's sweet. I'm too tired to argue with it.”",
      meh:"“I'm trying to work out what you want, exactly.”",
      bad:"“Please keep your voice down. I'm not in the mood.”",
      awful:"“I deal with people like you at work. Goodnight.”"},
    invite:"“Oh, come in. Quietly. I'll find you a chair.”",
    slam:"“Goodnight. I mean it.” The latch clicks." },

  { id:"haskell", name:"Ambrose Haskell", title:"Mr. Haskell", role:"Clock collector, 79", no:22,
    glimpse:"Dozens of clocks ticking out of step. A glass case of silver glints behind the curtain.",
    opening:"A long pause, then a slow voice. “It's very late for visitors. State your business.”",
    w:{charm:0,flatter:1,sob:1,offer:1,bluff:-1,menace:-3},
    aff:{courier:-1,lost:1,canvass:0,neighbor:1,inspector:0},
    baseSusp:10, ward:3, slamHeat:2, drainHeat:2, value:35, vamp:false,
    likes:["clock","watch","antique","history","old","silver","collect","repair","time","brandy","pendulum"],
    dislikes:["modern","digital","sell","undead","night","cheap"],
    lines:{
      charm:"I heard your clocks chiming from the street. I had to see where such a sound came from.",
      flatter:"That grandfather clock in your window looks like a real Black Forest piece.",
      sob:"I'm a long way from home and the night has turned cold. May I warm up a moment?",
      offer:"I found an old pocket watch on the road. I thought an expert should see it.",
      bluff:"Estate appraiser. I'm told you have pieces worth a valuation.",
      menace:"Open the door, old man. You can't stop what's coming."},
    react:{
      great:"“Now that is someone who knows horology. Come closer to the light.”",
      good:"“Hm. Reasonable enough. Go on.”",
      meh:"“Time is passing, young man. Make your point.”",
      bad:"“I've heard better lies from worse-looking men.”",
      awful:"“You smell of the grave, friend. Leave my step.”"},
    invite:"“Very well. Come in, and mind the case of silver. Do not touch it.”",
    slam:"“Not a chance.” A heavy bolt, then another, then the sound of a drawer opening." }
];

/* Free-text keyword model */
const KW = {
  flatter:["beautiful","lovely","handsome","gorgeous","amazing","wonderful","talented","impressive","smart","clever","great","love your","admire"],
  sob:["help","lost","cold","stranded","sick","hungry","lonely","tired","broke","dizzy","stuck","phone died","please"],
  offer:["gift","free","bring","brought","share","treat","coffee","tea","pizza","cookie","bread","money","deal","present"],
  bluff:["inspector","inspection","official","police","city","council","survey","gas leak","delivery","records","license","appraiser","county","landlord"],
  menace:["or else","open up","open the door","must","obey","demand","let me in","right now","you will","listen to me"],
  charm:["hello","hi","hey","good evening","evening","friend","sorry to bother","pleasure","nice to meet","excuse me","thank","kind"]
};
const VAMP = ["vampire","fang","bite","blood","undead","coffin","suck","immortal"];
