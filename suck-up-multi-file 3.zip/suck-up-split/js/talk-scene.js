(function(){
if(!window.THREE) return;
const T=THREE; let renderer;
try{ renderer=new T.WebGLRenderer({antialias:true}); }catch(e){ return; }
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
const el=document.createElement("div"); el.style.cssText="width:100%;height:100%"; el.appendChild(renderer.domElement);
const scene=new T.Scene(); scene.background=new T.Color(0x0b1230); scene.fog=new T.Fog(0x0b1230,10,30);
const cam=new T.PerspectiveCamera(42,1,0.1,60); cam.position.set(0.3,1.55,4.3); cam.lookAt(-0.7,1.6,0);
scene.add(new T.HemisphereLight(0x8090d0,0x201830,0.8));
const porch=new T.PointLight(0xffc878,1.1,18); porch.position.set(-0.8,2.6,1.5); scene.add(porch);
const M=(c)=>new T.MeshLambertMaterial({color:c});
const add=(g,m,x,y,z,par)=>{const o=new T.Mesh(g,m);o.position.set(x,y,z);(par||scene).add(o);return o;};
// house front, door frame, warm interior, porch
add(new T.BoxGeometry(14,7,0.5),M(0x2c2a5c),0,3.5,-0.6);
add(new T.BoxGeometry(2.2,1.6,0.1),M(0x14183a),-3.4,2.3,-0.3); add(new T.BoxGeometry(2.4,0.15,0.2),M(0xf0dfa4),-3.4,1.45,-0.2);
add(new T.BoxGeometry(2.6,3.6,0.6),new T.MeshBasicMaterial({color:0x1b1e46}),-0.8,1.8,-0.55);
const slab=add(new T.BoxGeometry(1.9,3.7,0.15),M(0xf0dfa4),0.9,1.85,-0.15); slab.rotation.y=-1.0; slab.position.x=1.3;
for(const [w,h,x,y] of [[0.25,3.9,-2.2,1.95],[0.25,3.9,0.6,1.95],[3.05,0.25,-0.8,3.85]]) add(new T.BoxGeometry(w,h,0.7),M(0xd9c48a),x,y,-0.4);
add(new T.BoxGeometry(14,0.3,8),M(0x2a2630),0,-0.15,3);
for(let i=0;i<8;i++)for(let j=0;j<4;j++)if((i+j)%2)add(new T.BoxGeometry(0.4,0.02,0.4),M(0x4a5fa8),-1.8+i*0.4,0.01,-0.4+j*0.4);
add(new T.SphereGeometry(0.18,10,8),new T.MeshBasicMaterial({color:0xffd58a}),-0.8,4.3,0.2);
// player: blue-skinned vampire seen over-the-shoulder from behind, cape + red collar
const me=new T.Group(); scene.add(me); me.position.set(1.5,0,2.2); me.rotation.y=-Math.PI/2-0.5; me.scale.setScalar(1.0);
add(new T.CylinderGeometry(0.55,0.7,1.5,12),M(0x1c1030),0,0.75,0,me);
add(new T.CylinderGeometry(0.62,0.62,0.18,12),M(0xc8202e),0,1.5,0,me);
add(new T.BoxGeometry(1.5,1.6,0.18),M(0x120a24),0,0.9,-0.5,me);
add(new T.SphereGeometry(0.52,16,12),M(0x5a8fd8),0,1.95,0.05,me);
const hood=add(new T.SphereGeometry(0.58,16,12,0,Math.PI*2,0,Math.PI*0.55),M(0x2a1740),0,2.05,-0.02,me);
add(new T.ConeGeometry(0.1,0.35,6),M(0x5a8fd8),0.5,1.95,0,me).rotation.z=-Math.PI/2;
add(new T.ConeGeometry(0.14,0.45,8),M(0x5a8fd8),0,1.88,0.6,me).rotation.x=Math.PI/2;
add(new T.BoxGeometry(0.3,0.3,0.9),M(0x1c1030),0.45,1.15,0.55,me);
// resident (rebuilt per resident)
let resG=null,resId="",mouth=null,head=null;
function buildRes(r){
  if(resG){scene.remove(resG);} resG=new T.Group(); scene.add(resG); resG.position.set(-0.8,0,0.1); resG.scale.setScalar(1.25); resId=r.id;
  const a=AV[r.id]||{skin:"#e0b090",hair:"#222",top:"#556"}, C=x=>new T.Color(x);
  add(new T.CylinderGeometry(0.55,0.7,1.5,12),M(C(a.top)),0,0.75,0,resG);
  head=new T.Group(); head.position.y=1.9; resG.add(head);
  add(new T.SphereGeometry(0.5,16,12),M(C(a.skin)),0,0,0,head);
  add(new T.SphereGeometry(0.53,16,10,0,Math.PI*2,0,Math.PI*0.5),M(C(a.hair)),0,0.04,-0.04,head);
  if(a.bun) add(new T.SphereGeometry(0.2,10,8),M(C(a.hair)),0,0.62,-0.1,head);
  if(a.hat) add(new T.CylinderGeometry(0.45,0.5,0.35,12),M(C(a.hat)),0,0.62,0,head);
  for(const s of [-1,1]){
    add(new T.SphereGeometry(0.06,8,6),new T.MeshBasicMaterial({color:0x111111}),s*0.19,0.08,0.46,head);
    if(a.glasses){const g=add(new T.TorusGeometry(0.13,0.02,6,14),M(0x222222),s*0.19,0.08,0.47,head);}
  }
  mouth=add(new T.TorusGeometry(0.13,0.025,6,12,Math.PI),M(0x5a2a2a),0,-0.17,0.47,head);
}
let active=false,raf=0,mood="";
function setMood(){
  const c=S.convo, last=c&&[...c.log].reverse().find(e=>e.who==="them"); mood=last&&last.mood||"";
  if(mouth){mouth.rotation.z=mood==="colder"?0:Math.PI; mouth.scale.y=mood===""||mood==="unmoved"?0.15:1;}
}
function resize(){const s=el.parentNode;if(!s)return;const w=s.clientWidth||600,h=s.clientHeight||340;renderer.setSize(w,h);cam.aspect=w/h;cam.updateProjectionMatrix();}
window.addEventListener("resize",()=>{if(active)resize();});
function loop(now){
  if(!active){raf=0;return;} raf=requestAnimationFrame(loop);
  const t=now/1000;
  if(head){head.rotation.z=Math.sin(t*1.3)*0.05; head.position.y=1.9+Math.sin(t*2)*(S.busy?0.05:0.015);}
  me.position.y=Math.sin(t*1.6)*0.02; 
  renderer.render(scene,cam);
}
window.Talk3D={sync(){
  const slot=document.getElementById("talk-slot");
  if(slot&&S.convo&&S.cur!=null){
    const r=RES[S.cur]; if(resId!==r.id||!resG)buildRes(r);
    hood.material.color.setHex(DROPS[S.convo.pretext]?0xffb020:0x2a1740);
    slot.appendChild(el); active=true; resize(); setMood(); if(!raf)raf=requestAnimationFrame(loop);
  } else { active=false; if(el.parentNode)el.parentNode.removeChild(el); }
}};
})();
