(function(){
if(!window.THREE) return;
const T=THREE; let renderer;
try{ renderer=new T.WebGLRenderer({antialias:true}); }catch(e){ return; }
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
const el=document.createElement("div"); el.className="world3d";
el.appendChild(renderer.domElement);
const help=document.createElement("div"); help.className="w3-help"; help.textContent="W A S D move · drag or ← → look · E knock"; el.appendChild(help);
const prompt=document.createElement("div"); prompt.className="w3-prompt"; prompt.hidden=true; el.appendChild(prompt);
const pad=document.createElement("div"); pad.className="w3-pad";
pad.innerHTML='<button data-k="w">▲</button><div><button data-k="a">◀</button><button data-k="s">▼</button><button data-k="d">▶</button></div>';
el.appendChild(pad);
const kb=document.createElement("button"); kb.className="w3-knock"; kb.textContent="Knock"; kb.disabled=true; el.appendChild(kb);
kb.addEventListener("click",()=>doKnock());

const scene=new T.Scene(), night=new T.Color(0x0a0f26), dawnC=new T.Color(0xff9a55);
scene.background=night.clone(); scene.fog=new T.Fog(0x0a0f26,35,140);
const cam=new T.PerspectiveCamera(60,1,0.1,450);
scene.add(new T.HemisphereLight(0x7f8fd0,0x1a1530,0.95));
const moonL=new T.DirectionalLight(0xaab8ff,0.7); moonL.position.set(-20,40,10); scene.add(moonL);
const M=(c,o)=>new T.MeshLambertMaterial(Object.assign({color:c},o||{}));
const box=(w,h,d,mat,x,y,z,par)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);(par||scene).add(m);return m;};

// ground, road, sidewalks
const grass=new T.Mesh(new T.PlaneGeometry(520,200),M(0x15241c)); grass.rotation.x=-Math.PI/2; scene.add(grass);
box(200,0.05,12,M(0x23262f),0,0.03,0);
for(let x=-96;x<=96;x+=6) box(2.5,0.06,0.25,M(0xc9b24a),x,0.06,0);
box(200,0.15,1.6,M(0x3a3f52),0,0.07,6.9); box(200,0.15,1.6,M(0x3a3f52),0,0.07,-6.9);
// moon and stars
const moon=new T.Mesh(new T.SphereGeometry(6,24,16),new T.MeshBasicMaterial({color:0xeef0ff,fog:false})); moon.position.set(-60,55,-110); scene.add(moon);
{const g=new T.BufferGeometry(),p=[];for(let i=0;i<400;i++){const a=Math.random()*6.283,r=120+Math.random()*30,h=20+Math.random()*90;p.push(Math.cos(a)*r,h,Math.sin(a)*r);}
g.setAttribute("position",new T.Float32BufferAttribute(p,3));scene.add(new T.Points(g,new T.PointsMaterial({color:0xffffff,size:1.3,fog:false})));}
// lamps
for(const x of [-84,-60,-36,-12,12,36,60,84]){
  const z=7.4; box(0.2,4.6,0.2,M(0x1b1e2c),x,2.3,z); const b=new T.Mesh(new T.SphereGeometry(0.4,12,8),new T.MeshBasicMaterial({color:0xffd58a})); b.position.set(x,4.8,z); scene.add(b);
}
for(const x of [-72,-48,-24,0,24,48,72]){const l=new T.PointLight(0xffc878,0.9,30); l.position.set(x,5,7); scene.add(l);}

// houses
const COLS=[0x6b5a8a,0x56709a,0x8a5a78,0x4f7f90,0x8a7458,0x5a5a8f], ROOFS=[0x3a2a5e,0x2c3f6b,0x4b2742,0x2a4a58,0x4a3a2a,0x33335c];
const SLOTX=[-52,-52,0,0,52,52], houses=[], doors=[];
function numTex(n){const c=document.createElement("canvas");c.width=128;c.height=64;const x=c.getContext("2d");x.fillStyle="#10152e";x.fillRect(0,0,128,64);x.fillStyle="#ffb454";x.font="bold 34px sans-serif";x.textAlign="center";x.textBaseline="middle";x.fillText("No. "+n,64,34);return new T.CanvasTexture(c);}
RES.forEach((r,i)=>{
  const north=(i%2===0), hx=SLOTX[i], hz=north?-13:13, g=new T.Group();
  g.position.set(hx,0,hz); g.rotation.y=north?0:Math.PI; scene.add(g);
  box(10,5,8,M(COLS[i]),0,2.5,0,g);
  const roof=new T.Mesh(new T.ConeGeometry(7.6,3,4),M(ROOFS[i])); roof.rotation.y=Math.PI/4; roof.scale.z=0.8; roof.position.y=6.5; g.add(roof);
  if(i%2===0) box(1,2.2,1,M(ROOFS[i]),2.8,7,-1,g);
  box(1.8,2.7,0.2,M(0x2a1a14),3,1.35,4.05,g);
  box(2.6,0.2,1.2,M(0x3a3f52),3,0.1,4.6,g);
  const win=new T.Mesh(new T.BoxGeometry(3,2,0.15),new T.MeshBasicMaterial({color:0xffb454})); win.position.set(-2.2,2.7,4.05); g.add(win);
  const sign=new T.Mesh(new T.PlaneGeometry(1.4,0.7),new T.MeshBasicMaterial({map:numTex(r.no)})); sign.position.set(3,3.5,4.12); g.add(sign);
  const boards=new T.Group(); for(const a of [0.7,-0.7]){const p=box(2.6,0.22,0.1,M(0x5a3a22),3,1.35,4.25,boards);p.rotation.z=a;} boards.visible=false; g.add(boards);
  { const n=buildNPC(r,g); n.position.set(-0.5,0,6.4); n.rotation.y=0.25; }
  houses.push({win,boards}); doors.push({x:hx+(north?3:-3), z:north?9:-9});
});

// resident NPCs: one stylised character in each front yard
const npcs=[];
function buildNPC(r,gp){
  const a=AV[r.id]||{skin:"#e0b090",hair:"#222",top:"#556"}, C=x=>new T.Color(x), g=new T.Group();
  const sk=M(C(a.skin)), top=M(C(a.top)), hr=M(C(a.hair)), pants=M(0x22263a), shoe=M(0x15151c);
  for(const x of [-0.17,0.17]){ box(0.22,0.7,0.24,pants,x,0.55,0,g); box(0.26,0.14,0.36,shoe,x,0.1,0.05,g); }
  const body=new T.Mesh(new T.CylinderGeometry(0.34,0.42,0.95,12),top); body.position.y=1.3; g.add(body);
  const sh=new T.Mesh(new T.SphereGeometry(0.34,12,8,0,Math.PI*2,0,Math.PI/2),top); sh.position.y=1.77; g.add(sh);
  const arms=[];
  for(const x of [-1,1]){ const ar=new T.Group(); ar.position.set(x*0.46,1.7,0); g.add(ar);
    const am=new T.Mesh(new T.CylinderGeometry(0.1,0.09,0.75,8),top); am.position.y=-0.38; ar.add(am);
    const hd=new T.Mesh(new T.SphereGeometry(0.1,8,6),sk); hd.position.y=-0.8; ar.add(hd); arms.push(ar); }
  const head=new T.Group(); head.position.y=2.2; g.add(head);
  head.add(new T.Mesh(new T.SphereGeometry(0.4,20,16),sk));
  const cap=new T.Mesh(new T.SphereGeometry(0.43,20,12,0,Math.PI*2,0,Math.PI*0.5),hr); cap.position.set(0,0.04,-0.04); head.add(cap);
  const back=new T.Mesh(new T.SphereGeometry(0.42,16,10,0,Math.PI*2,Math.PI*0.35,Math.PI*0.3),hr); back.position.set(0,0.0,-0.1); head.add(back);
  if(a.bun){ const b=new T.Mesh(new T.SphereGeometry(0.16,10,8),hr); b.position.set(0,0.5,-0.2); head.add(b); }
  if(a.hat){ const h=new T.Mesh(new T.CylinderGeometry(0.36,0.42,0.3,14),M(C(a.hat))); h.position.y=0.5; head.add(h);
    const br=new T.Mesh(new T.CylinderGeometry(0.5,0.5,0.05,16),M(C(a.hat))); br.position.set(0,0.36,0.08); head.add(br); }
  for(const x of [-1,1]){
    const eye=new T.Mesh(new T.SphereGeometry(0.055,8,6),new T.MeshBasicMaterial({color:0x111111})); eye.position.set(x*0.15,0.04,0.37); head.add(eye);
    const ear=new T.Mesh(new T.SphereGeometry(0.07,8,6),sk); ear.position.set(x*0.4,0,0); head.add(ear);
    if(a.glasses){ const gl=new T.Mesh(new T.TorusGeometry(0.11,0.016,6,16),M(0x222222)); gl.position.set(x*0.15,0.04,0.38); head.add(gl); }
    const ch=new T.Mesh(new T.SphereGeometry(0.06,8,6),new T.MeshBasicMaterial({color:0xe88a8a})); ch.position.set(x*0.24,-0.1,0.33); ch.scale.z=0.4; head.add(ch);
  }
  if(a.glasses) box(0.1,0.015,0.015,M(0x222222),0,0.05,0.4,head);
  const mouth=new T.Mesh(new T.TorusGeometry(0.09,0.016,6,12,Math.PI),new T.MeshBasicMaterial({color:0x6a2a2a})); mouth.position.set(0,-0.12,0.38); mouth.rotation.z=Math.PI; head.add(mouth);
  if(a.phones){ const hb=new T.Mesh(new T.TorusGeometry(0.42,0.03,6,16,Math.PI),M(0x111111)); hb.position.y=0.05; head.add(hb); }
  if(a.badge) box(0.12,0.14,0.04,M(0xe8c14a),0.17,1.55,0.36,g);
  const sd=new T.Mesh(new T.CircleGeometry(0.5,16),new T.MeshBasicMaterial({color:0,transparent:true,opacity:0.3})); sd.rotation.x=-Math.PI/2; sd.position.y=0.03; g.add(sd);
  g.scale.setScalar(1.15); gp.add(g); npcs.push({head,arms,g,ph:Math.random()*6,id:r.id}); return g;
}
// extra scenery: filler houses and trees to fill out the town
{const dm=new T.MeshBasicMaterial({color:0x2a3050});
for(const fx of [-90,-76,-64,-38,-26,-14,14,26,38,64,76,90]) for(const n of [true,false]){
  const k=Math.abs(fx*7+(n?1:3))%6, fg=new T.Group(); fg.position.set(fx,0,n?-13:13); fg.rotation.y=n?0:Math.PI; scene.add(fg);
  box(8,4.2,7,M(COLS[k]),0,2.1,0,fg);
  const rf=new T.Mesh(new T.ConeGeometry(6.2,2.6,4),M(ROOFS[k])); rf.rotation.y=Math.PI/4; rf.scale.z=0.8; rf.position.y=5.5; fg.add(rf);
  box(1.5,2.4,0.2,M(0x2a1a14),2.4,1.2,3.55,fg);
  const w=new T.Mesh(new T.BoxGeometry(2.4,1.6,0.15),(k+fx)%3===0?new T.MeshBasicMaterial({color:0xffb454}):dm); w.position.set(-2,2.4,3.55); fg.add(w);
}
for(let x=-94;x<=94;x+=9) for(const z of [-9.2,9.2]){ if(Math.abs(x%26)<2) continue;
  box(0.4,1.6,0.4,M(0x3a2a1a),x,0.8,z); const c=new T.Mesh(new T.SphereGeometry(1.3,10,8),M(0x1d3a2a)); c.position.set(x,2.6,z); scene.add(c); }
}
// vampire
const vamp=new T.Group(); scene.add(vamp);
const dark=M(0x14101e), red=M(0x8a1020), skin=M(0xe8dfe6);
function limb(x,y,len,r,mat){const g=new T.Group();g.position.set(x,y,0);const m=new T.Mesh(new T.CylinderGeometry(r,r*0.85,len,8),mat);m.position.y=-len/2;g.add(m);vamp.add(g);return g;}
const legL=limb(-0.15,0.85,0.85,0.12,dark), legR=limb(0.15,0.85,0.85,0.12,dark);
const armL=limb(-0.42,1.7,0.75,0.09,dark), armR=limb(0.42,1.7,0.75,0.09,dark);
const torso=new T.Mesh(new T.CylinderGeometry(0.3,0.4,0.95,10),dark); torso.position.y=1.3; vamp.add(torso);
const sash=new T.Mesh(new T.CylinderGeometry(0.32,0.34,0.14,10),red); sash.position.y=1.05; vamp.add(sash);
box(0.7,0.35,0.12,red,0,1.82,-0.2,vamp); 
const cape=new T.Group(); cape.position.set(0,1.75,-0.28); vamp.add(cape);
const cm=new T.Mesh(new T.PlaneGeometry(0.95,1.25),new T.MeshLambertMaterial({color:0x6e0c1a,side:T.DoubleSide})); cm.position.y=-0.62; cape.add(cm);
const head=new T.Mesh(new T.SphereGeometry(0.25,16,12),skin); head.position.y=2.0; vamp.add(head);
const hair=new T.Mesh(new T.SphereGeometry(0.27,16,10,0,Math.PI*2,0,Math.PI*0.55),dark); hair.position.set(0,2.03,-0.03); vamp.add(hair);
for(const s of [-1,1]){
  const e=new T.Mesh(new T.SphereGeometry(0.035,8,6),new T.MeshBasicMaterial({color:0xff2038})); e.position.set(s*0.09,2.03,0.23); vamp.add(e);
  const f=new T.Mesh(new T.ConeGeometry(0.025,0.09,6),new T.MeshBasicMaterial({color:0xffffff})); f.rotation.x=Math.PI; f.position.set(s*0.06,1.89,0.22); vamp.add(f);
  const h=new T.Mesh(new T.SphereGeometry(0.08,8,6),skin); h.position.set(s*0.42,0.92,0); vamp.add(h); (s<0?armL:armR).userData.hand=h;
}
const shadow=new T.Mesh(new T.CircleGeometry(0.55,16),new T.MeshBasicMaterial({color:0,transparent:true,opacity:0.35})); shadow.rotation.x=-Math.PI/2; shadow.position.y=0.12; scene.add(shadow);

// state and input
let active=false, raf=0, gameRef=null, nearIdx=-1, lastKey="", last=0, phase=0;
const P={x:-88,z:0,yaw:Math.PI/2,pitch:0.35,heading:Math.PI/2};
const keys={};
function reset(){P.x=-88;P.z=0;P.yaw=Math.PI/2;P.pitch=0.35;P.heading=Math.PI/2;nearIdx=-1;lastKey="";}
function typing(t){return t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA");}
function doKnock(){ if(active&&nearIdx>=0&&!S.busy){ const i=nearIdx; knock(i); } }
document.addEventListener("keydown",e=>{
  if(!active||typing(e.target)) return;
  const k=e.key.toLowerCase();
  if(["w","a","s","d","arrowup","arrowdown","arrowleft","arrowright"].includes(k)){keys[k]=true;e.preventDefault();}
  else if(k==="e"||k==="enter"||k===" "){e.preventDefault();doKnock();}
});
document.addEventListener("keyup",e=>{keys[e.key.toLowerCase()]=false;});
window.addEventListener("blur",()=>{for(const k in keys)keys[k]=false;});
let drag=null;
renderer.domElement.addEventListener("pointerdown",e=>{drag={x:e.clientX,y:e.clientY};renderer.domElement.setPointerCapture(e.pointerId);});
renderer.domElement.addEventListener("pointermove",e=>{if(!drag)return;P.yaw-=(e.clientX-drag.x)*0.005;P.pitch=Math.max(0.1,Math.min(0.85,P.pitch-(e.clientY-drag.y)*0.004));drag={x:e.clientX,y:e.clientY};});
const endDrag=()=>{drag=null;}; renderer.domElement.addEventListener("pointerup",endDrag); renderer.domElement.addEventListener("pointercancel",endDrag);
pad.addEventListener("pointerdown",e=>{const b=e.target.closest("[data-k]");if(b)keys[b.dataset.k]=true;});
const padUp=e=>{pad.querySelectorAll("[data-k]").forEach(b=>keys[b.dataset.k]=false);};
pad.addEventListener("pointerup",padUp); pad.addEventListener("pointerleave",padUp); pad.addEventListener("pointercancel",padUp);
prompt.addEventListener("click",e=>{if(e.target.closest("[data-w3knock]"))doKnock();});

function updatePrompt(){
  let best=-1,bd=3.6;
  for(let i=0;i<doors.length;i++){const d=Math.hypot(P.x-doors[i].x,P.z-doors[i].z);if(d<bd){bd=d;best=i;}}
  nearIdx=best;
  kb.disabled=!(best>=0&&S.houses[best].status!=="fed"&&S.houses[best].status!=="barred");
  const h=best>=0?S.houses[best]:null, key=best<0?"":best+"|"+h.status+"|"+h.known;
  if(key===lastKey) return; lastKey=key;
  if(best<0){prompt.hidden=true;return;}
  const r=RES[best], label={fresh:"Door closed",slammed:"Slammed on you",barred:"Barred for good",fed:"Fed on"}[h.status];
  const can=!(h.status==="fed"||h.status==="barred");
  prompt.innerHTML='<b>No. '+r.no+' Larkspur Lane</b> · '+(h.known?esc(r.name):"Unknown resident")+' · '+label+'<br><i>'+esc(r.glimpse)+'</i>'+(can?'<br><button class="btn primary" data-w3knock>Knock (E) · 15 min</button>':'');
  prompt.hidden=false;
}
function updateHouses(){
  S.houses.forEach((h,i)=>{const o=houses[i];o.boards.visible=(h.status==="slammed"||h.status==="barred");o.win.material.color.setHex((h.status==="fed"||h.status==="barred")?0x222a44:0xffb454);});
}
function setDawn(){const p=clamp((S.t/DAWN-0.55)/0.45,0,1)*0.9;const c=night.clone().lerp(dawnC,p*0.8);scene.background.copy(c);scene.fog.color.copy(c);}
function resize(){const s=el.parentNode;if(!s)return;const w=s.clientWidth||600,h=s.clientHeight||400;renderer.setSize(w,h);cam.aspect=w/h;cam.updateProjectionMatrix();}
window.addEventListener("resize",()=>{if(active)resize();});

function loop(now){
  if(!active){raf=0;return;} raf=requestAnimationFrame(loop);
  const dt=Math.min(0.05,(now-(last||now))/1000); last=now;
  if(keys.arrowleft)P.yaw+=dt*1.8; if(keys.arrowright)P.yaw-=dt*1.8;
  const iz=((keys.w||keys.arrowup)?1:0)-((keys.s||keys.arrowdown)?1:0), ix=(keys.d?1:0)-(keys.a?1:0);
  const fx=Math.sin(P.yaw),fz=Math.cos(P.yaw),rx=-Math.cos(P.yaw),rz=Math.sin(P.yaw);
  let mx=fx*iz+rx*ix,mz=fz*iz+rz*ix; const ml=Math.hypot(mx,mz);
  if(ml>0){mx/=ml;mz/=ml;P.x=Math.max(-94,Math.min(94,P.x+mx*9*dt));P.z=Math.max(-8,Math.min(8,P.z+mz*6*dt));
    let da=Math.atan2(mx,mz)-P.heading;da=Math.atan2(Math.sin(da),Math.cos(da));P.heading+=da*Math.min(1,dt*12);phase+=dt*9;}
  const sw=ml>0?Math.sin(phase)*0.7:0, t=now/1000;
  legL.rotation.x=sw; legR.rotation.x=-sw; armL.rotation.x=-sw*0.8; armR.rotation.x=sw*0.8;
  for(const a of [armL,armR]) if(a.userData.hand){a.userData.hand.position.z=Math.sin(a===armL?-sw*0.8:sw*0.8)*-0.7; a.userData.hand.position.y=1.7-Math.cos(a===armL?-sw*0.8:sw*0.8)*0.78;}
  cape.rotation.x=(ml>0?0.5:0.12)+Math.sin(t*(ml>0?9:2))*0.08;
  vamp.position.set(P.x,ml>0?Math.abs(Math.sin(phase))*0.06:0,P.z); vamp.rotation.y=P.heading; shadow.position.x=P.x; shadow.position.z=P.z;
  const d=6.5,cx=P.x-fx*d*Math.cos(P.pitch),cz=P.z-fz*d*Math.cos(P.pitch);
  cam.position.set(Math.max(-100,Math.min(100,cx)),1.5+d*Math.sin(P.pitch),Math.max(-8.8,Math.min(8.8,cz)));
  cam.lookAt(P.x,1.4,P.z);
  for(const n of npcs){ n.g.position.y=Math.sin(t*1.8+n.ph)*0.02; n.head.rotation.y=Math.sin(t*0.7+n.ph)*0.35; n.head.rotation.z=Math.sin(t*1.1+n.ph)*0.04; n.arms[0].rotation.z=0.08+Math.sin(t*1.8+n.ph)*0.03; n.arms[1].rotation.z=-0.08-Math.sin(t*1.8+n.ph)*0.03; }
  updatePrompt(); renderer.render(scene,cam);
}
window.World={sync(){
  const slot=document.getElementById("world-slot");
  if(S.view==="street"&&slot){
    slot.appendChild(el); active=true; if(gameRef!==S){gameRef=S;reset();}
    resize(); updateHouses(); setDawn(); lastKey=""; last=0; if(!raf)raf=requestAnimationFrame(loop);
  } else { active=false; for(const k in keys)keys[k]=false; if(el.parentNode)el.parentNode.removeChild(el); }
}};
})();
